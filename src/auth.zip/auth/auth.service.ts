import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  // Dummy user (bisa diganti dari DB)
  private users = [
    { id: 1, name: 'Admin', email: 'admin@example.com', password: 'admin123' },
  ];

  async validateUser(email: string, password: string) {
    const user = this.users.find(u => u.email === email && u.password === password);
    if (user) {
      const { password, ...result } = user;
      return result;
    }
    return null;
  }

  async login(user: any) {
    const payload = { name: user.name, sub: user.id };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
