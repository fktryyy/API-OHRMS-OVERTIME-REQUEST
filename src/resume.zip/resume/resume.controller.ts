import { Controller, Get, Post, Body } from '@nestjs/common';
import { ResumeService } from './resume.service';
import { CreateResumeDto } from './dto/create-resume.dto';

interface Resume {
  id: number;
  id_user: string;
  employee_id: number;
  department_id: number;
  totalOvertimeHours: number;
  totalOvertimeDays: number;
  notes: string;
}

@Controller('resume')
export class ResumeController {
  constructor(private readonly resumeService: ResumeService) {}

  @Post()
  create(@Body() createResumeDto: CreateResumeDto): Resume {
    return this.resumeService.create(createResumeDto);
  }

  @Get()
  findAll(): Resume[] {
    return this.resumeService.findAll();
  }
}
