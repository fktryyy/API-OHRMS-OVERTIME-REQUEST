// src/resume/resume.service.ts
import { Injectable } from '@nestjs/common';
import { CreateResumeDto } from './dto/create-resume.dto';

@Injectable()
export class ResumeService {
  private resumes: (CreateResumeDto & { id: number })[] = [];
  private idCounter = 1;

  create(createResumeDto: CreateResumeDto) {
    const resume = {
      id: this.idCounter++,
      ...createResumeDto,
    };
    this.resumes.push(resume);
    return resume;
  }

  findAll() {
    return this.resumes;
  }
}
